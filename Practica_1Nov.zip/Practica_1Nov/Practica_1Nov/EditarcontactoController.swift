//
//  EditarcontactoController.swift
//  Practica_1Nov
//
//  Created by Alumno on 11/3/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation
import UIKit

class EditarcontactoController : UIViewController {
    
    var contacto : Datos?
    var callbackActualizarTablaContactos : (() -> Void)?
    
    @IBOutlet weak var txtCelular: UITextField!
    @IBOutlet weak var txtCorreo: UITextField!
    @IBOutlet weak var txtNombre: UITextField!
    
    override func viewDidLoad() {
        
        self.title = "Editar Contacto"
    
        txtNombre.text = contacto!.nombre
        txtCorreo.text = contacto!.correo
        txtCelular.text = contacto!.nunmero
        
    }
    @IBAction func doTapGuardar(_ sender: Any) {
        contacto!.nombre = txtNombre.text!
        contacto!.correo = txtCorreo.text!
        contacto!.nunmero = txtCelular.text!
        
        callbackActualizarTablaContactos!()
    }
}
